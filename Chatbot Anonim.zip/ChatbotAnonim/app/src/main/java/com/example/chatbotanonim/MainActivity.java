package com.example.chatbotanonim;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatbotanonim.api.BotResponse;
import com.example.chatbotanonim.api.RasaApiService;
import com.example.chatbotanonim.api.RetrofitClient;
import com.example.chatbotanonim.api.UserMessage;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private String currentUsername;
    private RecyclerView recyclerChat;
    private EditText editMessage;
    private ImageButton btnSend;
    private ChatAdapter chatAdapter;
    private List<Message> messageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this); // BARU

        currentUsername = getIntent().getStringExtra("USER_NAME");
        if (currentUsername == null) currentUsername = "Guest";

        recyclerChat = findViewById(R.id.recycler_chat);
        editMessage = findViewById(R.id.edit_message);
        btnSend = findViewById(R.id.btn_send);

        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter();

        List<Message> history = dbHelper.getChatHistory(currentUsername);
        if (history.isEmpty()) {
            addMessageToChat("Halo " + currentUsername + "! Saya Bot Konsultasi. Apa yang sedang kamu rasakan?", "bot");
        } else {
            for (Message m : history) {
                chatAdapter.addMessage(m);
            }
        }

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerChat.setLayoutManager(layoutManager);
        recyclerChat.setAdapter(chatAdapter);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = editMessage.getText().toString().trim();
                if (!message.isEmpty()) {
                    sendMessageToRasa(message);
                }
            }
        });
    }

    private void sendMessageToRasa(String message) {
        addMessageToChat(message, "user");
        editMessage.setText("");

        UserMessage req = new UserMessage("user", message);

        Call<List<BotResponse>> call = RetrofitClient.getService().sendMessage(req);

        call.enqueue(new Callback<List<BotResponse>>() {
            @Override
            public void onResponse(Call<List<BotResponse>> call, Response<List<BotResponse>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<BotResponse> botResponses = response.body();

                    for (BotResponse botResp : botResponses) {
                        addMessageToChat(botResp.getText(), "bot");
                    }
                } else {
                    addMessageToChat("Bot tidak merespon (Error " + response.code() + ")", "bot");
                }
            }

            @Override
            public void onFailure(Call<List<BotResponse>> call, Throwable t) {
                addMessageToChat("Gagal: " + t.getMessage(), "bot");
                Log.e("API_ERROR", "onFailure: " + t.getMessage());
                Log.e("API_ERROR", "Cause: " + t.getCause());
                t.printStackTrace(); // <-- tambahkan ini
            }
        });
    }

    private void addMessageToChat(String message, String sender) {
        Message newMessage = new Message(message, sender);
        chatAdapter.addMessage(newMessage);
        recyclerChat.smoothScrollToPosition(chatAdapter.getItemCount() - 1);

        dbHelper.insertMessage(currentUsername, message, sender);
    }

}