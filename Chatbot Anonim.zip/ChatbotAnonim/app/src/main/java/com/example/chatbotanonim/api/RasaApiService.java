package com.example.chatbotanonim.api;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface RasaApiService {
    @POST("webhooks/rest/webhook")
    Call<List<BotResponse>> sendMessage(@Body UserMessage message);
}
