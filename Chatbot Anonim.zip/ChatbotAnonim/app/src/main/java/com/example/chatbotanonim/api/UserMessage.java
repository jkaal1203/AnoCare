package com.example.chatbotanonim.api;

public class UserMessage {
    private String sender;
    private String message;

    public UserMessage(String sender, String message) {
        this.sender = sender;
        this.message = message;
    }

}