package com.example.chatbotanonim.api;

public class BotResponse {
    private String text;
    private String recipient_id;

    public String getText() {
        return text;
    }

    public String getRecipient_id() {
        return recipient_id;
    }
}
