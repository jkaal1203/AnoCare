package com.example.chatbotanonim;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "SkripsiChat.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "chat_history";
    private static final String COL_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_MESSAGE = "message";
    private static final String COL_SENDER = "sender";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Query buat tabel: CREATE TABLE chat_history (...)
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_MESSAGE + " TEXT, " +
                COL_SENDER + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertMessage(String username, String message, String sender) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_MESSAGE, message);
        contentValues.put(COL_SENDER, sender);

        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1; // Kalau -1 berarti gagal
    }

    public List<Message> getChatHistory(String username) {
        List<Message> chatList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_USERNAME + " = ?", new String[]{username});

        if (cursor.moveToFirst()) {
            do {
                String msg = cursor.getString(2);
                String sender = cursor.getString(3);

                chatList.add(new Message(msg, sender));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return chatList;
    }
}
