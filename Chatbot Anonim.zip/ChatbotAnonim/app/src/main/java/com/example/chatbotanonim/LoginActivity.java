package com.example.chatbotanonim;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText inputUsername;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inputUsername = findViewById(R.id.input_username);
        btnLogin = findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = inputUsername.getText().toString().trim();

                if (username.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Harap isi nama samaran dulu ya!", Toast.LENGTH_SHORT).show();
                } else {
                    // Pindah ke Halaman Chat (MainActivity)
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    // Bawa nama user ke halaman sebelah
                    intent.putExtra("USER_NAME", username);
                    startActivity(intent);
                    finish(); // Agar kalau ditekan back tidak bali ke login lagi
                }
            }
        });
    }
}